
<?php
	defined('BASEPATH') OR exit ('Açao nao permitida');

    class Vendas extends CI_controller {

    	public function __construct() {
			parent::__construct();
			if(!$this->ion_auth->logged_in() ) {
				$this-session-set_flashdata('info', 'Sessão Expirada');
				redirect('login');
			}
			$this->load->model('Vendas_model');
		}
		public function index() {
			$data = array(
				'titulo'=> 'Vendas Cadastradas',

				'styles' => array(
					'vendor/datatables/datatables.bootstrap4.min.css',
				),
				'scripts' => array(
					'vendor/datatables/jquery.dataTables.min.js',
					'vendor/datatables/datatables.bootstrap4.min.js',
					'vendor/datatables/app.js'
				),
				'vendas' => $this->Vendas_model->get_all(),
			);
//			echo '<pre>';
//			print_r($data['vendas']);
//			exit();

			//echo '<pre>';
			//print_r($data['ordens_servicos']);
			//exit();

			$this->load->view('layout/header', $data);
			$this->load->view('vendas/index');
			$this->load->view('layout/footer');
		}

	}
?>
