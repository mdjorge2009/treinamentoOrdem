<?php
	defined('BASEPATH') OR exit ('Açao nao permitida');

		class sistema extends CI_Controller {
			public function __construct() {
				parent::__construct();
					if(!$this->ion_auth->logged_in() ) {
						$this->session->set_flashdata('info', 'Sessao Expirada!');
						redirect('login');
					}
			}
			public function index() {
				$data = array(
					'titulo' => 'Editor de Informações',

					'scripts' => array(
						'vendor/mask/jquery.mask.min.js',
						'vendor/mask/app.js',

					),

					'sistema' =>$this->core_model->get_by_id('sistema', array('sistema_id' =>1)),
				);
				$this->form_validation->set_rules('sistema_razao_social', 'Razão Social', 'required|min_length[10]|max_length[145]') ;
				$this->form_validation->set_rules('sistema_nome_fantasia', 'Nome Fantasia', 'required|min_length[10]|max_length[145]') ;
				$this->form_validation->set_rules('sistema_cnpj', '', 'required|exact_length[14]') ;
				$this->form_validation->set_rules('sistema_ie', '', 'required|max_length[25]') ;
				$this->form_validation->set_rules('sistema_telefone_fixo', '', 'required|exact_length[13]') ;
				$this->form_validation->set_rules('sistema_telefone_movel', '', 'required|exact_length[14]') ;
				$this->form_validation->set_rules('sistema_email', '', 'required|valid_email|max_length[100]') ;
				$this->form_validation->set_rules('sistema_site_url', '', 'required|valid_url|max_length[100]') ;
				$this->form_validation->set_rules('sistema_email', 'Url do Site', 'required|valid_email|max_length[100]') ;
				$this->form_validation->set_rules('sistema_cep', 'CEP', 'required|exact_length[9]') ;
				$this->form_validation->set_rules('sistema_endereco', 'Endereço', 'required|max_length[145]') ;
				$this->form_validation->set_rules('sistema_numero', 'Numero', 'max_length[25]') ;
				$this->form_validation->set_rules('sistema_cidade', 'Cidade', 'required|max_length[45]') ;
				$this->form_validation->set_rules('sistema_estado', 'Estado', 'required|exact_length[2]') ;
				$this->form_validation->set_rules('sistema_txt_ordem_servico', '', 'max_length[300]') ;


				if($this->form_validation->run()) {

				/*
				[sistema_razao_social] => Mundial Supermercados
				[sistema_nome_fantasia] => Mundial Marica
				[sistema_cnpj] => 14236000000125
				[sistema_ie] => 001245698
				[sistema_telefone_fixo] => (21)3333-3333
				[sistema_telefone_movel] => (21)99999-9999
				[sistema_email] => local@gmail.com
				[sistema_site_url] => http://localhost/ordem/sistema
				[sistema_endereco] => Rua das Gardenias
				[sistema_numero] => 17
				[sistema_cidade] => Marica
				[sistema_cep] => 24930-460
				[sistema_estado] => RJ
				[sistema_txt_ordem_servico] => teste teste

				*/

				$data = elements(
					array(
						'sistema_razao_social',
						'sistema_nome_fantasia',
						'sistema_cnpj',
						'sistema_ie',
						'sistema_telefone_fixo',
						'sistema_telefone_movel',
						'sistema_email',
						'sistema_site_url',
						'sistema_endereco',
						'sistema_numero',
						'sistema_cidade',
						'sistema_cep',
						'sistema_estado',
						'sistema_txt_ordem_servico',


					), $this->input->post()
				);

				$data = html_escape($data);

				$this->core_model->update('sistema', $data, array('sistema_id'=>1) );
				redirect('sistema');

				//echo '<pre>';
				//print_r($this->input->post());
				//exit();





				}else{
				$this->load->view('layout/header', $data);
				$this->load->view('sistema/index');
				$this->load->view('layout/footer');


				}


			}


		}


?>
