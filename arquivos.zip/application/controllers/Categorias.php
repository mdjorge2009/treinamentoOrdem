
<?php
	defined('BASEPATH') OR exit ('Açao nao permitida');
    class Categorias extends CI_controller {

    	public function __construct() {
			parent::__construct();
			if(!$this->ion_auth->logged_in() ) {
				$this-session-set_flashdata('info', 'Sessão Expirada');
				redirect('login');
			}
		}
		public function index() {
			$data = array(
				'titulo'=> 'Categorias Cadastradas',

				'styles' => array(
					'vendor/datatables/datatables.bootstrap4.min.css',
				),
				'scripts' => array(
					'vendor/datatables/jquery.dataTables.min.js',
					'vendor/datatables/datatables.bootstrap4.min.js',
					'vendor/datatables/app.js'
				),
				'categorias' => $this->core_model->get_all('categorias'),
			);
			$this->load->view('layout/header',$data);
			$this->load->view('categorias/index');
			$this->load->view('layout/footer');
		}
		public function edit($categoria_id = NULL) {
			if (!$categoria_id || !$this->core_model->get_by_id('categorias', array('categoria_id' => $categoria_id)) ) {
				$this->session->set_flashdata('error', 'Categoria não Localizado');
				redirect('categorias');
			}else {
				$this->form_validation->set_rules('categoria_nome', '', 'trim|required|min_length[5]|max_length[145]');
				$this->form_validation->set_rules('categoria_ativa', '', 'trim|required');
				if($this->form_validation->run() ) {
				$data = elements(
					array(
						'categoria_nome',
						'categoria_ativa',

					), $this->input->post()
				);
				$data = html_escape($data);
				$this->core_model->update('categorias', $data, array('categoria_id' => $categoria_id));
				redirect('categorias');
				//	echo '<pre>';
				//	print_r($this->input->post());
				//	exit();
				}else{
					$data = array(
					'titulo'=> 'Atualizar Categorias',

					'scripts' => array(
						'vendor/mask/jquery.mask.min.js',
						'vendor/mask/app.js',
					),
					'categoria' => $this->core_model->get_by_id('categorias', array('categoria_id' =>$categoria_id)),
				);
				$this->load->view('layout/header',$data);
				$this->load->view('categorias/edit');
				$this->load->view('layout/footer');
				}
			}
		}
		public function add() {
			$this->form_validation->set_rules('categoria_nome', '', 'trim|required|min_length[5]|max_length[145]|is_unique[marcas.marca_nome]');
			$this->form_validation->set_rules('categoria_ativa', '', 'trim|required');

			if($this->form_validation->run() ) {
				$categoria_ativa = $this->input->post('categoria_ativa');
				if($this->db->table_exists('produtos')) {
					if($categoria_ativa == 0 && $this->core_model->get_by_id('produtos', array('produto_categoria_id'=> $categoria_id, 'produto_ativo' => 1))) {
						$this->session->set_flashdata('error', 'Categoria sendo Utilizada');
						redirect('categorias');
					}
				}
				$data = elements(
					array(
						'categoria_nome',
						'categoria_ativa',
					), $this->input->post()
				);
				$data = html_escape($data);
				$this->core_model->insert('categorias', $data);
				redirect('categorias');
				//	echo '<pre>';
				//	print_r($this->input->post());
				//	exit();

			}else{
				$data = array(
					'titulo'=> 'Cadastar Categorias',

					'scripts' => array(
						'vendor/mask/jquery.mask.min.js',
						'vendor/mask/app.js',
					),
				);
				$this->load->view('layout/header',$data);
				$this->load->view('categorias/add');
				$this->load->view('layout/footer');
			}
		}
	}
?>
