<?php
	defined('BASEPATH') OR exit ('Açao nao permitida');
    class Servicos extends CI_controller {
    	public function __construct() {
			parent::__construct();
			if(!$this->ion_auth->logged_in() ) {
				$this-session-set_flashdata('info', 'Sessão Expirada');
				redirect('login');
			}
		}
		public function index() {
			$data = array(
				'titulo' => 'Serviços Cadastrados',

				'styles' => array(
					'vendor/datatables/datatables.bootstrap4.min.css',
				),
				'scripts' => array(
					'vendor/datatables/jquery.dataTables.min.js',
					'vendor/datatables/datatables.bootstrap4.min.js',
					'vendor/datatables/app.js'
				),
				'servicos' => $this->core_model->get_all('servicos'),
			);
			$this->load->view('layout/header', $data);
			$this->load->view('servicos/index');
			$this->load->view('layout/footer');
		}
		public function edit($servico_id = NULL) {
			if (!$servico_id || !$this->core_model->get_by_id('servicos', array('servico_id' => $servico_id)) ) {
				$this->session->set_flashdata('error', 'Serviço não Localizado');
				redirect('servicos');
			}else {
				$this->form_validation->set_rules('servico_nome', '', 'trim|required|min_length[10]|max_length[145]');
				$this->form_validation->set_rules('servico_preco', '', 'trim|required');
				$this->form_validation->set_rules('servico_descricao', '', 'trim|required|min_length[10]|max_length[400]');

				if($this->form_validation->run() ) {
				$data = elements(
					array(
						'servico_nome',
						'servico_preco',
						'servico_descricao',
						'servico_ativo',

					), $this->input->post()
				);
				$data = html_escape($data);
				$this->core_model->update('servicos', $data, array('servico_id' => $servico_id));
				redirect('servicos');
				}else{
					$data = array(
					'titulo'=> 'Atualizar Servicos',

					'scripts' => array(
						'vendor/mask/jquery.mask.min.js',
						'vendor/mask/app.js',
					),
					'servico' => $this->core_model->get_by_id('servicos', array('servico_id' =>$servico_id)),
				);
				$this->load->view('layout/header',$data);
				$this->load->view('servicos/edit');
				$this->load->view('layout/footer');
				}
			}
		}
		public function add() {
			$this->form_validation->set_rules('servico_nome', '', 'trim|required|min_length[10]|max_length[145]|is_unique[servicos.servico_nome]');
			$this->form_validation->set_rules('servico_preco', '', 'trim|required');
			$this->form_validation->set_rules('servico_descricao', '', 'trim|required|min_length[10]|max_length[400]');

			if($this->form_validation->run() ) {
			$data = elements(
				array(
					'servico_nome',
					'servico_preco',
					'servico_descricao',
					'servico_ativo',

				), $this->input->post()
			);
			$data = html_escape($data);
			$this->core_model->insert('servicos', $data);
			redirect('servicos');
				//	echo '<pre>';
				//	print_r($this->input->post());
				//	exit();
			}else{
				$data = array(
					'titulo'=> 'Cadastar Servicos',

					'scripts' => array(
						'vendor/mask/jquery.mask.min.js',
						'vendor/mask/app.js',
					),
				);
				$this->load->view('layout/header',$data);
				$this->load->view('servicos/add');
				$this->load->view('layout/footer');
			}
		}
	}
?>
