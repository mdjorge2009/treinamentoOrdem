
<?php
	defined('BASEPATH') OR exit ('Açao nao permitida');

	class Usuarios extends CI_Controller{

		public function __construct() {
			parent::__construct();

			if(!$this->ion_auth->logged_in() ) {
			$this->session->set_flashdata('info', 'Sessão Expirada');
			redirect('login');
		}
	}
		public function index() {

			if(!$this->ion_auth->is_admin() ) {
				$this->session->set_flashdata('info', 'Sem permisao de acesso');
				redirect('home');
			}
			$data = array(
				'titulo'=> 'Usuarios Cadastrados',

				'styles' => array(
					'vendor/datatables/datatables.bootstrap4.min.css',
				),
				'scripts' => array(
					'vendor/datatables/jquery.dataTables.min.js',
					'vendor/datatables/datatables.bootstrap4.min.js',
					'vendor/datatables/app.js'
				),
				'usuarios' => $this->ion_auth->users()->result(),
			);

			$this->load->view('layout/header', $data);
			$this->load->view('usuarios/index');
			$this->load->view('layout/footer');
		}
		public function add() {

			if(!$this->ion_auth->is_admin() ) {
				$this->session->set_flashdata('info', 'Sem permisao de acesso');
				redirect('home');
			}
				$this->form_validation->set_rules('first_name', '', 'trim|required');
				$this->form_validation->set_rules('last_name', '', 'trim|required');
				$this->form_validation->set_rules('email', '', 'trim|required|valid_email|is_unique[usuarios.email]');
				$this->form_validation->set_rules('username', '', 'trim|required|is_unique[usuarios.username]');
				$this->form_validation->set_rules('password', 'Senha', 'required|min_length[5]|max_length[255]');
				$this->form_validation->set_rules('confirm_password', 'Confirme', 'matches[password]');

					if($this->form_validation->run()) {

						$username = $this->security->xss_clean($this->input->post('username'));
						$password = $this->security->xss_clean($this->input->post('password'));
						$email = $this->security->xss_clean($this->input->post('email'));

						$additional_data = array(
							'first_name' => $this->input->post('first_name'),
							'last_name' => $this->input->post('last_name'),
							'username' => $this->input->post('username'),
							'active' => $this->input->post('active'),
						);
						$group = array($this->input->post('perfil_usuario'));
						$additional_data = $this->security->xss_clean($additional_data);
						$group = $this->security->xss_clean($group);
//						echo '<pre>';
//						print_r($additional_data);
//						exit();
						if($this->ion_auth->register($username, $password, $email, $additional_data, $group)) {
							$this->session->set_flashdata('sucesso', 'Dados Salvo com sucesso');
						}else{
							$this->session->set_flashdata('error', 'Ops!! Ocorreu algum erro');
						}
						redirect('usuarios');
					}else{
						//erro de validação
						$data = array(
							'titulo' => 'Cadastrar Usuario',
						);
						$this->load->view('layout/header', $data);
						$this->load->view('usuarios/add');
						$this->load->view('layout/footer');
					}
		}
		public function edit($user_id = NULL) {
//			if ($this->session->userdata('user_id' != $usuario_id)) {
//				$this->session->set_flashdata('error', 'Sem permissão');
//				redirect('home');
//
//			}


			if (!$user_id || !$this->ion_auth->user($user_id)->row() ) {
				$this->session->set_flashdata('error', 'Usuario não Encontrado');
				redirect('usuarios');
			} else {

				$this->form_validation->set_rules('first_name', ' ', 'trim|required');
				$this->form_validation->set_rules('last_name', '', 'trim|required');
				$this->form_validation->set_rules('email', '', 'trim|required|valid_email|callback_email_check');
				$this->form_validation->set_rules('username', '', 'trim|required|callback_username_check');
				$this->form_validation->set_rules('password', 'Senha', 'min_length[5]|max_length[255]');
				$this->form_validation->set_rules('confirm_password', 'Confirme', 'matches[password]');
				$this->form_validation->set_rules('grupo_id', ' ', 'trim|required');

            	if($this->form_validation->run() ) {
      				$data = elements(
      					array(
      						'first_name',
      						'last_name',
      						'email',
      						'username',
      						'active',
      						'password',
      						'grupo_id',
      					), $this->input->post()

      				);

					$data = $this->security->xss_clean($data);
							/*verifica se foi passado senha */
					$password = $this->input->post('password');
					if(!$password) {
						unset($data['password']);
					}
					if($this->ion_auth->update($user_id, $data)) {

						$perfil_usuario_db = $this->ion_auth->get_users_groups($user_id)->row();
						$perfil_usuario_post = $this->input->post('pefil_usuario');

						if($perfil_usuario_post != $perfil_usuario_db->id) {
							/*Atualiza se for diferente*/

//							$this->ion_auth->remove_from_group($perfil_usuario_db->id, $user_id);
//							$this->ion_auth->add_to_group($perfil_usuario_post, $user_id);
						}
							$this->session->set_flashdata('sucesso', 'Dados salvos');
						}else{
							$this->session->set_flashdata('error', 'Erro ao salvar');
					}
			if(!$this->ion_auth->is_admin() ) {
				$this->session->set_flashdata('info', 'Sem permisao de acesso');
				redirect('usuarios');
			}else{
				redirect('home');
			}


            }else{
				$data = array(
					'titulo' => 'Editar Usuario',
					'usuario' => $this->ion_auth->user($user_id)->row(),
					'perfil_usuario' => $this->ion_auth->get_users_groups($user_id)->row(),
				);


				$this->load->view('layout/header', $data);
				$this->load->view('usuarios/edit');
				$this->load->view('layout/footer');
            }
			}
		}
		public function email_check($email) {
			$usuario_id = $this->input->post('usuario_id');

			if($this->core_model->get_by_id('users', array('email' => $email, 'id !=' => $usuario_id))) {

				$this->form_validation->set_message('email_check', 'Email ja existe');
				return FALSE;
			}else{
				return TRUE;
			}
		}
		public function username_check($username) {
			$usuario_id = $this->input->post('usuario_id');

			if($this->core_model->get_by_id('users', array('username' => $username, 'id !=' => $usuario_id))) {

				$this->form_validation->set_message('username_check', 'Usuario ja existe');
				return FALSE;

			}else{
				return TRUE;
			}
		}
		public function del($usuario_id = NULL){
			if(!$this->ion_auth->is_admin() ) {
				$this->session->set_flashdata('info', 'Sem permisao de acesso');
				redirect('home');
			}

			if(!$usuario_id || !$this->ion_auth->usuarios($usuario_id)->row()){
				$this->session->set_flashdata('error', 'Usuario nao localizado');
					redirect('usuarios');
			}
			if($this->ion_auth->is_admin($usuario_id)){
				$this->session->set_flashdata('error', 'Administrador nao pode ser Deletado');
				redirect('usuarios');
			}
			if($this->ion_auth->delete_usuarios($usuario_id)) {
				$this->session->set_flashdata('sucesso', 'Usuario Excluido');
				redirect('usuarios');
			}else{
				$this->session->set_flashdata('error', 'Ops algo deu errado');
				redirect('usuarios');
			}
		}
	}
?>

