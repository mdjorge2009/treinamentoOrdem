<?php
	defined('BASEPATH') OR exit ('Açao nao permitida');

    class Fornecedores extends CI_controller {

    	public function __construct() {
			parent::__construct();

			if(!$this->ion_auth->logged_in() ) {
				$this-session-set_flashdata('info', 'Sua sessão expirou');
				redirect('login');
			}
		}
		public function index() {
			$data = array(
				'titulo'=> 'Fornecedores Cadastrados',

				'styles' => array(
					'vendor/datatables/datatables.bootstrap4.min.css',
				),
				'scripts' => array(
					'vendor/datatables/jquery.dataTables.min.js',
					'vendor/datatables/datatables.bootstrap4.min.js',
					'vendor/datatables/app.js'
				),
				'fornecedores' => $this->core_model->get_all('fornecedores'),
			);
			$this->load->view('layout/header', $data);
			$this->load->view('fornecedores/index');
			$this->load->view('layout/footer');
		}
		public function edit($forncedor_id = NULL) {
			if(!$forncedor_id || !$this->core_model->get_by_id('fornecedores', array('fornecedor_id' => $fornecedor_id)) ) {
				$this->session->set_flashdata('error', 'Fornecedor não Localizado');
				redirect('fornecedores');

				}else{
					$data = array(
					'titulo'=> 'Atualização de Fornecedor',
						'scripts' => array(
						'vendor/mask/jquery.mask.min.js',
						'vendor/mask/app.js',

					),
					'fornecedor' =>$this->core_model->get_by_id('fornecedores', array('fornecedor_id' =>$fornecedor_id)),
			);
			echo '<pre>';
			print_r($data['fornecedor']);
			exit();

			$this->load->view('layout/header',$data);
			$this->load->view('fornecedores/edit');
			$this->load->view('layout/footer');
				}
			}
		public function add() {

			$this->form_validation->set_rules('fornecedor_razao', '', 'trim|required|min_length[4]|max_length[200]|callback_check_fornecedor_razao');
			$this->form_validation->set_rules('fornecedor_nome_fantasia', '', 'trim|required|min_length[4]|max_length[150]|callback_check_fornecedor_nome_fantasia');
			$this->form_validation->set_rules('fornecedor_cnpj', '', 'trim|required|max_length[18]');
			$this->form_validation->set_rules('fornecedor_ie', '', 'trim|required|min_length[5]|max_length[15]');
			$this->form_validation->set_rules('fornecedor_email', '', 'trim|required|max_length[50]');
			$this->form_validation->set_rules('fornecedor_telefone', '', 'trim|required|max_length[14]|is_unique[fornecedores.fornecedor_telefone]');
			$this->form_validation->set_rules('fornecedor_celular', '', 'trim|required|max_length[15]|is_unique[fornecedores.fornecedor_celular]');
			$this->form_validation->set_rules('fornecedor_contato', '', 'trim|required|max_length[45]');
			$this->form_validation->set_rules('fornecedor_cep', '', 'trim|required|min_length[8]|max_length[9]');
			$this->form_validation->set_rules('fornecedor_endereco', '', 'trim|required|max_length[155]');
			$this->form_validation->set_rules('fornecedor_numero_endereco', '','trim|required|max_length[6]');
			$this->form_validation->set_rules('fornecedor_bairro', '', 'trim|required|max_length[45]');
			$this->form_validation->set_rules('fornecedor_complemento', '', 'trim|required|max_length[145]');
			$this->form_validation->set_rules('fornecedor_cidade', '', 'trim|max_length[50]');
			$this->form_validation->set_rules('fornecedor_estado', '', 'trim|required|exact_length[2]');
			$this->form_validation->set_rules('fornecedor_obs', '', 'max_length[400]');

			if($this->form_validation->run() ) {
			//exit('Validado');
				$data = elements(
					array(
						'fornecedor_razao',
						'fornecedor_nome_fantasia',
						'fornecedor_cnpj',
						'fornecedor_ie',
						'fornecedor_email',
						'fornecedor_telefone',
						'fornecedor_celular',
						'fornecedor_contato',
						'fornecedor_endereco',
						'fornecedor_numero_endereco',
						'fornecedor_complemento',
						'fornecedor_bairro',
						'fornecedor_cep',
						'fornecedor_cidade',
						'fornecedor_estado',
						'fornecedor_ativo',
						'fornecedor_obs',
					),
					$this->input->post()
				);
				$data['fornecedor_estado'] = strtoupper($this->input->post('fornecedor_estado') );
				$data = html_escape($data);
				$this->core_model->insert('fornecedores', $data);
				redirect('fornecedores');

					//	echo '<pre>';
					//	print_r($this->input->post());
					//	exit();

			}else{
				$data = array(
					'titulo'=> 'Cadastrar Fornecedor',
					'scripts' => array(
					'vendor/mask/jquery.mask.min.js',
					'vendor/mask/app.js',
					),
				);
				$this->load->view('layout/header',$data);
				$this->load->view('fornecedores/add');
				$this->load->view('layout/footer');
			}
		}
		public function check_fornecedor_razao ($fornecedor_razao) {
    		$fornecedor_id = $this->input->post('fornecedor_id');
    		if ($this->core_model->get_by_id('fornecedores', array('fornecedor_razao' => $fornecedor_razao, 'fornecedor_id !=' => $fornecedor_id ))) {
    			$this->form_validation->set_message('fornecedor_razao', 'RS ja Cadastrado') ;
    			return false;
    		}else{
    			return true;
    		}
    	}
		public function check_fornecedor_nome_fantasia ($fornecedor_nome_fantasia) {
    		$fornecedor_id = $this->input->post('fornecedor_id');
    		if ($this->core_model->get_by_id('fornecedores', array('fornecedor_nome_fantasia' => $fornecedor_nome_fantasia, 'fornecedor_id !=' => $fornecedor_id ))) {
    			$this->form_validation->set_message('fornecedor_nome_fantasia', 'N. Fantasia ja Cadastrado') ;
    			return false;
    		}else{
    			return true;
    		}
    	}
		public function check_fornecedor_email ($fornecedor_email) {
			$fornecedor_id = $this->input->post('fornecedor_id');

			if($this->core_model->get_by_id('fornecedores', array('fornecedor_email' => $fornecedor_email, 'fornecedor_id !=' => $fornecedor_id ) ) ) {
				$this->form_validation->set_message('check_email', 'E-mail ja Cadastrado') ;
				return false;
			}else{
				return true;
			}
		}
		public function check_fornecedor_ie ($fornecedor_ie) {
			$fornecedor_id = $this->input->post('fornecedor_id');

			if($this->core_model->get_by_id('fornecedores', array('fornecedor_ie' => $fornecedor_ie, 'fornecedor_id !=' => $fornecedor_id ) ) ) {
				$this->form_validation->set_message('check_fornecedor_ie', 'Inscriçao ja Cadastrado') ;
				return false;
			}else{
				return true;
			}
		}
	}
?>
